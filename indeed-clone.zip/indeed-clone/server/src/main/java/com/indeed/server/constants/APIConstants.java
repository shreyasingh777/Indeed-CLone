package com.indeed.server.constants;

public class APIConstants {

    public static final String GET_ALL_POSTS = "/posts";

    public static final String SAVE_POST = "/post";
}
