

export const routePath = {
    home        : '/',
    posts       : '/posts',
    create      : '/create',
    invalid     : '/*' 
}